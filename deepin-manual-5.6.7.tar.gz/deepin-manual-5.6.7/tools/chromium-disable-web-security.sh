#!/bin/bash

# Start new chromium profile with web security off.

chromium --user-data-dir=/tmp/deepin-manual --disable-web-security
