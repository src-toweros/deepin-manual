#!/bin/sh

/usr/share/deepin-manual/dman $@