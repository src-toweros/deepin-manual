<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="62"/>
        <source>Manual</source>
        <translation>Žinynas</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="64"/>
        <source>Manual is designed to help users learn the operating system and its applications, providing specific instructions and function descriptions.</source>
        <translation>Žinynas yra sukurtas, kad padėtų naudotojams išmokti naudotis operacine sistema ir jos programomis, jame yra pateikiamos tam tikros instrukcijos ir funkcijų aprašai.</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="34"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Applications</source>
        <translation>Programos</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>No search results</source>
        <translation>Nėra jokių paieškos rezultatų</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="41"/>
        <source>Home</source>
        <translation>Pradžia</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="43"/>
        <source>  result</source>
        <translation>  rezultatas</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="44"/>
        <source>  results</source>
        <translation>  rezultatų(-ai)</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>Kopijuoti</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="219"/>
        <source>Search</source>
        <translation>Ieškoti</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="148"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="218"/>
        <source>Search for &quot;%1&quot; in the full text</source>
        <translation>Ieškoti &quot;%1&quot; visame tekste</translation>
    </message>
</context>
<context>
    <name>WebWindow</name>
    <message>
        <location filename="../src/view/web_window.cpp" line="289"/>
        <source>Copy</source>
        <translation>Kopijuoti</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="325"/>
        <source>Ctrl+Alt+F</source>
        <translation>Vald+Alt+F</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="340"/>
        <source>Ctrl+F</source>
        <translation>Vald+F</translation>
    </message>
</context>
</TS>