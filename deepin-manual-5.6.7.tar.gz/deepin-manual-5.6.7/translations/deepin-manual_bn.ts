<?xml version="1.0" ?><!DOCTYPE TS><TS language="bn" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="82"/>
        <source>Deepin Manual</source>
        <translation>ডিপিন ম্যানুয়াল</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="83"/>
        <source>Deepin Manual is designed to help users learn deepin and Deepin applications, providing specific instructions and function descriptions.</source>
        <translation>ডিপিন ম্যানুয়াল তৈরী করা হয়েছে ব্যাবহারকারীদের ডিপিন এবং ডিপিন এপ্লিকেশন সম্পর্কে সুনির্দিষ্ট নির্দেশনা এবং কার্যবলীর বর্ণনা দিয়ে সাহায্য করতে।</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>কপি</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="32"/>
        <source>System</source>
        <translation>সিস্টেম</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="33"/>
        <source>Applications</source>
        <translation>এপ্লিকেশন</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Sorry, there are no search results of &quot;%1&quot;</source>
        <translation>দুঃখিত, এখানে &quot;%1&quot; এর কোনো ফলাফল নেই</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="36"/>
        <source>Change your keywords and try again, or search it in Deepin Wiki</source>
        <translation>আপনার আপনার কীওয়ার্ড পরিবর্তন করুন এবং আবার চেষ্টা করুন, বা Deepin Wiki তে এটি অনুসন্ধান করুন</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>Home</source>
        <translation>হোম</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="39"/>
        <source>Deepin Wiki</source>
        <translation>ডিপিন উইকি</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="113"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="162"/>
        <source>Search &quot;%1&quot; in the full text</source>
        <translation>সম্পূর্ণ টেক্সটে &quot;%1&quot; অনুসন্ধান করুন</translation>
    </message>
    <message>
        <location filename="../src/view/widget/title_bar.cpp" line="96"/>
        <source>Search</source>
        <translation>অনুসন্ধান করুন</translation>
    </message>
</context>
</TS>