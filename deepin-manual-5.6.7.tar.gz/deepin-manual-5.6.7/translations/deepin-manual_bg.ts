<?xml version="1.0" ?><!DOCTYPE TS><TS language="bg" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="82"/>
        <source>Deepin Manual</source>
        <translation>Deepin ръководство</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="83"/>
        <source>Deepin Manual is designed to help users learn deepin and Deepin applications, providing specific instructions and function descriptions.</source>
        <translation>Deepin ръководство е предназначен да помогне на потребителите да се запознаят с Deepin и Deepin приложенията, като предоставят конкретни инструкции и описания на функциите.</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>Копиране</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="32"/>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="33"/>
        <source>Applications</source>
        <translation>Приложения</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Sorry, there are no search results of &quot;%1&quot;</source>
        <translation>За съжаление няма резултати от търсенето на &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="36"/>
        <source>Change your keywords and try again, or search it in Deepin Wiki</source>
        <translation>Променете ключовите си думи и опитайте отново или ги потърсете Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>Home</source>
        <translation>Начало</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="39"/>
        <source>Deepin Wiki</source>
        <translation>Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="113"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="162"/>
        <source>Search &quot;%1&quot; in the full text</source>
        <translation>Търси &quot;%1&quot; в пълния текст</translation>
    </message>
    <message>
        <location filename="../src/view/widget/title_bar.cpp" line="96"/>
        <source>Search</source>
        <translation>Търсене</translation>
    </message>
</context>
</TS>