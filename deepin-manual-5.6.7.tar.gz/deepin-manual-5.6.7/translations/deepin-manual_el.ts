<?xml version="1.0" ?><!DOCTYPE TS><TS language="el" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="82"/>
        <source>Deepin Manual</source>
        <translation>Εγχειρίδιο Deepin</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="83"/>
        <source>Deepin Manual is designed to help users learn deepin and Deepin applications, providing specific instructions and function descriptions.</source>
        <translation>Το Deepin Manual έχει σχεδιαστεί για να βοηθήσει τους χρήστες να μάθουν το Deepin περιβάλλον αλλά και τις εφαρμογές, παρέχοντας λεπτομερής οδηγίες και περιγραφές λειτουργιών.</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>Αντιγραφή</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="32"/>
        <source>System</source>
        <translation>Σύστημα</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="33"/>
        <source>Applications</source>
        <translation>Εφαρμογές</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Sorry, there are no search results of &quot;%1&quot;</source>
        <translation>Συγνώμη δεν βρέθηκαν αποτελέσματα για την αναζήτηση &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="36"/>
        <source>Change your keywords and try again, or search it in Deepin Wiki</source>
        <translation>Άλλαξε τις λέξεις κλειδιά και ξανα προσπάθησε, ή αναζήτησε βοήθεια στο Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>Home</source>
        <translation>Αρχική</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="39"/>
        <source>Deepin Wiki</source>
        <translation>Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="113"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="162"/>
        <source>Search &quot;%1&quot; in the full text</source>
        <translation>Αναζήτηση για “%1” σε όλο το κείμενο</translation>
    </message>
    <message>
        <location filename="../src/view/widget/title_bar.cpp" line="96"/>
        <source>Search</source>
        <translation>Αναζήτηση</translation>
    </message>
</context>
</TS>