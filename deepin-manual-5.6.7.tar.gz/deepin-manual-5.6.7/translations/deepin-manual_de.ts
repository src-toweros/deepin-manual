<?xml version="1.0" ?><!DOCTYPE TS><TS language="de" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="62"/>
        <source>Manual</source>
        <translation>Handbuch</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="64"/>
        <source>Manual is designed to help users learn the operating system and its applications, providing specific instructions and function descriptions.</source>
        <translation>Das Benutzerhandbuch wurde entwickelt, um Anwender dabei zu unterstützen, das Betriebssystem und die Anwendungen mithilfe zugeschnittener Anleitungen und Funktionsbeschreibungen zu erlernen und kennen zu lernen.</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="34"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Applications</source>
        <translation>Anwendungen</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>No search results</source>
        <translation>Keine Suchergebnisse</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="41"/>
        <source>Home</source>
        <translation>Startseite</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="43"/>
        <source>  result</source>
        <translation>Ergebnis</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="44"/>
        <source>  results</source>
        <translation>Ergebnisse</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="219"/>
        <source>Search</source>
        <translation>Suchen</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="148"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="218"/>
        <source>Search for &quot;%1&quot; in the full text</source>
        <translation>Suche nach &quot;%1&quot; im Volltext</translation>
    </message>
</context>
<context>
    <name>WebWindow</name>
    <message>
        <location filename="../src/view/web_window.cpp" line="289"/>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="325"/>
        <source>Ctrl+Alt+F</source>
        <translation>Ctrl+Alt+F</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="340"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
</context>
</TS>