<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="62"/>
        <source>Manual</source>
        <translation>Příručka</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="64"/>
        <source>Manual is designed to help users learn the operating system and its applications, providing specific instructions and function descriptions.</source>
        <translation>Příručka je navržena tak, aby pomáhala uživatelům učit se pracovat s operačním systémem a přidruženými aplikacemi. Poskytuje pokyny k jeho specifikům a popisy fungování.</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="34"/>
        <source>System</source>
        <translation>Systém</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Applications</source>
        <translation>Aplikace</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>No search results</source>
        <translation>Nic nenalezeno</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="41"/>
        <source>Home</source>
        <translation>Domů</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="43"/>
        <source>  result</source>
        <translation>výsledek</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="44"/>
        <source>  results</source>
        <translation>výsledky</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>Zkopírovat</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="219"/>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="148"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="218"/>
        <source>Search for &quot;%1&quot; in the full text</source>
        <translation>Vyhledat „%1“ napříč celým textem</translation>
    </message>
</context>
<context>
    <name>WebWindow</name>
    <message>
        <location filename="../src/view/web_window.cpp" line="289"/>
        <source>Copy</source>
        <translation>Zkopírovat</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="325"/>
        <source>Ctrl+Alt+F</source>
        <translation>Ctrl+Alt+F</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="340"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
</context>
</TS>