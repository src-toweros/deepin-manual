<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="82"/>
        <source>Deepin Manual</source>
        <translation>Deepin Manuál</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="83"/>
        <source>Deepin Manual is designed to help users learn deepin and Deepin applications, providing specific instructions and function descriptions.</source>
        <translation>Deepin Manual je navrhnutý tak, aby pomohol používateľom učiť sa z aplikácií Deepin, ktoré poskytujú špecifické pokyny a popisy funkcií.</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>Kopírovať</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="32"/>
        <source>System</source>
        <translation>Systém</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="33"/>
        <source>Applications</source>
        <translation>Aplikácie</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Sorry, there are no search results of &quot;%1&quot;</source>
        <translation>Ľutujeme, ale neexistujú žiadne výsledky vyhľadávania pre &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="36"/>
        <source>Change your keywords and try again, or search it in Deepin Wiki</source>
        <translation>Zmeňte svoje kľúčové slová a skúste to znova alebo ich vyhľadajte na Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>Home</source>
        <translation>Domov</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="39"/>
        <source>Deepin Wiki</source>
        <translation>Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="113"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="162"/>
        <source>Search &quot;%1&quot; in the full text</source>
        <translation>Vyhľadať &quot;%1&quot; v plnom znení</translation>
    </message>
    <message>
        <location filename="../src/view/widget/title_bar.cpp" line="96"/>
        <source>Search</source>
        <translation>Vyhľadávanie</translation>
    </message>
</context>
</TS>