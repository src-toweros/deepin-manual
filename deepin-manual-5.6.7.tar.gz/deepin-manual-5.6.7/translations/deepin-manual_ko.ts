<?xml version="1.0" ?><!DOCTYPE TS><TS language="ko" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="62"/>
        <source>Manual</source>
        <translation>설명서</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="64"/>
        <source>Manual is designed to help users learn the operating system and its applications, providing specific instructions and function descriptions.</source>
        <translation>설명서는 사용자가 특정 지침 및 기능 설명을 제공, 운영 체제와 응용 프로그램을 배울 수 있도록 설계되었습니다.</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="34"/>
        <source>System</source>
        <translation>시스템</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Applications</source>
        <translation>응용프로그램</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>No search results</source>
        <translation>검색 결과 없음</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="41"/>
        <source>Home</source>
        <translation>홈</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="43"/>
        <source>  result</source>
        <translation>결과</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="44"/>
        <source>  results</source>
        <translation>결과</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>복사</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="219"/>
        <source>Search</source>
        <translation>검색</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="148"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="218"/>
        <source>Search for &quot;%1&quot; in the full text</source>
        <translation>전체 텍스트에서 &quot;%1&quot; 검색</translation>
    </message>
</context>
<context>
    <name>WebWindow</name>
    <message>
        <location filename="../src/view/web_window.cpp" line="289"/>
        <source>Copy</source>
        <translation>복사</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="325"/>
        <source>Ctrl+Alt+F</source>
        <translation>Ctrl+Alt+F</translation>
    </message>
    <message>
        <location filename="../src/view/web_window.cpp" line="340"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
</context>
</TS>