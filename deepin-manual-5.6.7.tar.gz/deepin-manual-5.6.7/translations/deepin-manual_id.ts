<?xml version="1.0" ?><!DOCTYPE TS><TS language="id" version="2.1">
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/app/dman.cpp" line="82"/>
        <source>Deepin Manual</source>
        <translation>Manual Deepin</translation>
    </message>
    <message>
        <location filename="../src/app/dman.cpp" line="83"/>
        <source>Deepin Manual is designed to help users learn deepin and Deepin applications, providing specific instructions and function descriptions.</source>
        <translation>Deepin Manual di desain untuk membantu pengguna dalam mempelajari deepin dan aplikasi Deepin, menyediakan instruksi yang spesifik dan juga deskripsi fungsi nya.</translation>
    </message>
    <message>
        <location filename="../src/view/web_event_delegate.cpp" line="63"/>
        <source>Copy</source>
        <translation>Salin</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="32"/>
        <source>System</source>
        <translation>Sistem</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="33"/>
        <source>Applications</source>
        <translation>Aplikasi</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="35"/>
        <source>Sorry, there are no search results of &quot;%1&quot;</source>
        <translation>Maaf, hasil pencarian dari &quot;%1&quot; tidak di temukan</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="36"/>
        <source>Change your keywords and try again, or search it in Deepin Wiki</source>
        <translation>Ganti kata kunci anda dan coba lagi, atau cari di Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="38"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../src/view/i18n_proxy.cpp" line="39"/>
        <source>Deepin Wiki</source>
        <translation>Deepin Wiki</translation>
    </message>
    <message>
        <location filename="../src/view/widget/search_completion_window.cpp" line="113"/>
        <location filename="../src/view/widget/search_completion_window.cpp" line="162"/>
        <source>Search &quot;%1&quot; in the full text</source>
        <translation>Cari &quot;%1&quot; in dalam kalimat</translation>
    </message>
    <message>
        <location filename="../src/view/widget/title_bar.cpp" line="96"/>
        <source>Search</source>
        <translation>Pencarian</translation>
    </message>
</context>
</TS>