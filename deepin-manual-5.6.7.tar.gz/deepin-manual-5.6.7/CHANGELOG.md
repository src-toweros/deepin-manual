<a name="2.0.19"></a>
## 2.0.19 (2019-04-10)


#### Features

*   Update manual to Deepin 15.10 ([6382be2f](https://github.com/linuxdeepin/deepin-manual/commit/6382be2fc840807d6ca2fe7bd35eb3bde81e6b64))
*   Release 15.9 ([9bad7846](https://github.com/linuxdeepin/deepin-manual/commit/9bad7846093e66c91c910567cea1509bdebcf5b2))



<a name="2.0.17"></a>
## 2.0.17 (2019-01-10)


#### Features

*   Release 15.9 ([9bad7846](https://github.com/linuxdeepin/deepin-manual/commit/9bad7846093e66c91c910567cea1509bdebcf5b2))



<a name="2.0.15"></a>
## 2.0.15 (2019-01-10)


#### Features

*   Release 15.9 ([9bad7846](https://github.com/linuxdeepin/deepin-manual/commit/9bad7846093e66c91c910567cea1509bdebcf5b2))



<a name="2.0.14"></a>
### 2.0.14 (2018-11-23)


#### Features

*   add genericName ([43246991](https://github.com/linuxdeepin/deepin-manual/commit/43246991b44854f922a2c9317a8ec3f8c3488bac))


2018-08-12 2.0.13 zccrs <zhangjide@deepin.com>
    * Update 15.8 manual

2018-08-12 2.0.12 Wu Rongjie <wurongjie@deepin.com>
    * Update deepin-file-manager manual

2018-08-3 2.0.11 Wu Rongjie <wurongjie@deepin.com>
    * Update manual

2018-07-24 2.0.10 Xu Shaohua <xushaohua2016@outlook.com>
    * Update manual

2018-06-12 2.0.9.3 Xu Shaohua <xushaohua2016@outlook.com>
    * Update manual

2018-06-08 2.0.9.2 Xu Shaohua <xushaohua2016@outlook.com>
    * Update manual

2018-06-08 2.0.9.1 Xu Shaohua <xushaohua2016@outlook.com>
    * Update manual

2018-05-30 2.0.9 Xu Shaohua <xushaohua2016@outlook.com>
    * Fix index layout

2018-05-30 2.0.8.1 deepinzhangshuang <zhangshuang@deepin.com>
    * fix:flatpak mapping error
    * Delete embeded libqdxcb.so

2018-05-17 2.0.8 Xu Shaohua <xushaohua2016@outlook.com>
    * Show completion window on active window
    * Upgrade manual of dde-file-manager to 1.7

2018-03-21 2.0.7.6 Xu Shaohua <xushaohua@deepin.com>
    * Update i18n

2018-03-21 2.0.7.5 Xu Shaohua <xushaohua@deepin.com>
    * Add WebEventDelegate to override default context menu

2018-03-21 2.0.7.4 Xu Shaohua <xushaohua@deepin.com>
    * Add DontCreateNativeWidgetSibings flag
    * Update i18n

2018-03-16 2.0.7.3 Xu Shaohua <xushaohua@deepin.com>
    * Start new instance if failed to register dbus service

2018-03-15 2.0.7.2 Xu Shaohua <xushaohua@deepin.com>
    * Update libdxcb plugin

2018-03-15 2.0.7.1 Xu Shaohua <xushaohua@deepin.com>
    * Enable bundled dxcb plugin

2018-03-15 2.0.7 Xu Shaohua <xushaohua@deepin.com>
    * Replace deepin-webengine with libqcef1

2018-03-07 2.0.6 Xu Shaohua <xushaohua@deepin.com>
    * Update i18n
    * Update manuals
    * Update icon padddings
    * Fix WindowManager::openManual() reentrent issue

2018-02-27 2.0.5 Xu Shaohua <xushaohua@deepin.com>
    * Update manual
    * Read manual id from desktop file
    * Do not scale svg files
    * Reorder manual list
    * Fix atttribute error of image element
    * Fix image viewer issue in hiDPI mode

2018-02-27 2.0.4 Xu Shaohua <xushaohua@deepin.com>
    * Update manual images
    * Fix search issue
    * Fix qt platform plugin issue
    * Fix icon alignment in index page

2018-02-08 2.0.3 Xu Shaohua <xushaohua@deepin.com>
    * Include libdxcb plugin
    * Be compactable with old version of dman
    * Add log manager
    * Fix global search navigation

2018-02-07 2.0.2 Xu Shaohua <xushaohua@deepin.com>
    * Depends on new version of dxcb plugin

2018-02-07 2.0.2 Xu Shaohua <xushaohua@deepin.com>
    * Depends on new version of dxcb plugin

2018-02-06 2.0.1 Xu Shaohua <xushaohua@deepin.com>
    * Tuning dman-search memory usage
    * Enable HiDPI pixmap
    * Tuning global search

2018-01-04 2.0.0 Xu Shaohua <xushaohua@deepin.com>
    * Rewrite to Qt5
